
  # 钉钉软件Web UI设计

  This is a code bundle for 钉钉软件Web UI设计. The original project is available at https://www.figma.com/design/veK92TgXfl3gBCTholkJym/%E9%92%89%E9%92%89%E8%BD%AF%E4%BB%B6Web-UI%E8%AE%BE%E8%AE%A1.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  